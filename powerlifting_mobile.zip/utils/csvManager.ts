import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { AppData, Workout, OneRMRecord } from '../types';

const DOCUMENTS_DIR = FileSystem.documentDirectory + 'PowerliftingTracker/';

export const ensureDirectoryExists = async () => {
  try {
    const dirInfo = await FileSystem.getInfoAsync(DOCUMENTS_DIR);
    if (!dirInfo.exists) {
      await FileSystem.makeDirectoryAsync(DOCUMENTS_DIR, { intermediates: true });
    }
  } catch (error) {
    console.error('Error creating directory:', error);
  }
};

export const exportToCSV = async (data: AppData): Promise<string> => {
  await ensureDirectoryExists();

  const timestamp = new Date().toISOString().split('T')[0];
  const filename = `powerlifting_backup_${timestamp}.csv`;
  const filepath = DOCUMENTS_DIR + filename;

  // Create CSV content with all data
  let csvContent = 'POWERLIFTING TRACKER BACKUP\n';
  csvContent += `Export Date: ${new Date().toISOString()}\n\n`;

  // Workouts section
  csvContent += 'WORKOUTS\n';
  csvContent += 'Date,Block,Exercise,Weight(kg),Reps,Sets,RPE,Tags,Notes\n';
  
  data.workouts.forEach(workout => {
    workout.sets.forEach(set => {
      csvContent += `${workout.date},${workout.blockId},${set.exerciseName},${set.weight},${set.reps},${set.sets},${set.rpe},"${set.tags.join('|')}","${set.notes}"\n`;
    });
  });

  csvContent += '\n1RM RECORDS\n';
  csvContent += 'Date,Exercise,Weight(kg),Notes\n';
  
  data.oneRMs.forEach(record => {
    csvContent += `${record.date},${record.exerciseName},${record.weight},"${record.notes}"\n`;
  });

  csvContent += '\n\nEXERCISES\n';
  csvContent += 'Name,Category,Custom\n';
  
  data.exercises.forEach(exercise => {
    csvContent += `${exercise.name},${exercise.category},${exercise.isCustom}\n`;
  });

  try {
    await FileSystem.writeAsStringAsync(filepath, csvContent);
    return filepath;
  } catch (error) {
    console.error('Error writing CSV:', error);
    throw error;
  }
};

export const shareCSV = async (filepath: string) => {
  try {
    if (!(await Sharing.isAvailableAsync())) {
      alert('Sharing is not available on this device');
      return;
    }
    await Sharing.shareAsync(filepath);
  } catch (error) {
    console.error('Error sharing file:', error);
  }
};

export const getBackupFiles = async (): Promise<string[]> => {
  try {
    await ensureDirectoryExists();
    const files = await FileSystem.readDirectoryAsync(DOCUMENTS_DIR);
    return files.filter(file => file.endsWith('.csv'));
  } catch (error) {
    console.error('Error reading backup files:', error);
    return [];
  }
};

export const deleteBackupFile = async (filename: string) => {
  try {
    const filepath = DOCUMENTS_DIR + filename;
    await FileSystem.deleteAsync(filepath);
  } catch (error) {
    console.error('Error deleting file:', error);
  }
};

export const getBackupFileInfo = async (filename: string) => {
  try {
    const filepath = DOCUMENTS_DIR + filename;
    const info = await FileSystem.getInfoAsync(filepath);
    return info;
  } catch (error) {
    console.error('Error getting file info:', error);
    return null;
  }
};

export const getAllBackupFiles = async () => {
  try {
    await ensureDirectoryExists();
    const files = await FileSystem.readDirectoryAsync(DOCUMENTS_DIR);
    const csvFiles = files.filter(f => f.endsWith('.csv'));
    
    const filesWithInfo = await Promise.all(
      csvFiles.map(async (file) => {
        const info = await getBackupFileInfo(file);
        return {
          name: file,
          size: info?.size || 0,
          modificationTime: info?.modificationTime || 0,
        };
      })
    );

    return filesWithInfo.sort((a, b) => b.modificationTime - a.modificationTime);
  } catch (error) {
    console.error('Error getting all backup files:', error);
    return [];
  }
};
