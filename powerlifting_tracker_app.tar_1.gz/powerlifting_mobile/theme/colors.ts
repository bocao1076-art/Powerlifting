// Dark Zone Purple & Black Theme
export const colors = {
  // Primary colors
  primary: '#8B5CF6', // Vibrant Purple
  primaryLight: '#A78BFA', // Light Purple
  primaryDark: '#6D28D9', // Dark Purple
  
  // Background colors
  background: '#0F0F1E', // Very Dark Purple-Black
  surface: '#1A1A2E', // Dark Purple-Black
  surfaceLight: '#252540', // Slightly lighter surface
  
  // Text colors
  text: '#E8E6FF', // Light purple-white
  textSecondary: '#B0ADCC', // Muted purple-gray
  textMuted: '#7A7793', // Darker muted
  
  // Accent colors
  accent: '#8B5CF6', // Same as primary
  accentLight: '#C4B5FD', // Very light purple
  
  // Status colors
  success: '#10B981', // Green
  warning: '#F59E0B', // Amber
  error: '#EF4444', // Red
  info: '#3B82F6', // Blue
  
  // Border colors
  border: '#2D2D45', // Subtle border
  borderLight: '#3F3F5F', // Lighter border
  
  // Special
  overlay: 'rgba(15, 15, 30, 0.8)',
  shadow: 'rgba(0, 0, 0, 0.5)',
};

export const gradients = {
  primary: ['#8B5CF6', '#6D28D9'],
  accent: ['#A78BFA', '#8B5CF6'],
  dark: ['#0F0F1E', '#1A1A2E'],
};

export const typography = {
  fontSize: {
    xs: 11,
    sm: 12,
    base: 14,
    lg: 16,
    xl: 18,
    '2xl': 20,
    '3xl': 24,
    '4xl': 28,
  },
  fontWeight: {
    light: '300',
    normal: '400',
    medium: '500',
    semibold: '600',
    bold: '700',
  },
  fontFamily: {
    default: 'System',
    bold: 'System',
  },
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  '2xl': 28,
  '3xl': 36,
};

export const borderRadius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  full: 9999,
};
