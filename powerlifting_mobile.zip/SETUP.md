# 🚀 Powerlifting Tracker Pro - Guia de Setup

## ⚡ Quick Start (5 minutos)

### Passo 1: Instale o Expo Go no seu celular
- **Android**: Baixe "Expo Go" na Google Play Store
- **iOS**: Baixe "Expo Go" na App Store

### Passo 2: Prepare seu computador
```bash
# Abra o terminal/cmd e execute:
cd /home/ubuntu/powerlifting_mobile
npm install -g expo-cli
```

### Passo 3: Inicie o app
```bash
cd /home/ubuntu/powerlifting_mobile
npm install
expo start
```

### Passo 4: Escaneie o QR Code
- Abra o Expo Go no seu celular
- Escaneie o QR code que aparecerá no terminal
- **Pronto!** Seu app está rodando! 🎉

---

## 📦 Compilar para APK Final

Depois de testar e estar satisfeito, compile para APK:

### Opção A: EAS Build (Recomendado - Online)
```bash
# 1. Crie conta gratuita em https://expo.dev
# 2. Faça login
eas login

# 3. Configure o projeto
eas build:configure

# 4. Compile para Android
eas build --platform android
```

O APK será enviado para seu email quando pronto!

### Opção B: Compilação Local (Requer Android Studio)
```bash
# 1. Instale Android Studio e configure SDK
# 2. Execute:
cd /home/ubuntu/powerlifting_mobile
npx expo prebuild --clean
cd android
./gradlew assembleRelease

# 3. APK fica em:
# android/app/build/outputs/apk/release/app-release.apk
```

---

## 🎮 Primeiros Passos no App

### 1. Dashboard
- Visualize seu total SBD
- Veja 1RMs registrados
- Acompanhe treinos recentes

### 2. Novo Treino
- Toque em "Novo Treino"
- Selecione exercício
- Digite carga, reps, séries
- RPE é calculado automaticamente!
- Salve o treino

### 3. Blocos de Treino
- Crie blocos: Acumulação, Intensificação, Realização, Deload
- Configure número da semana
- Organize seus treinos

### 4. Análise
- Veja gráficos de evolução
- Estatísticas por bloco
- Insights de progresso

### 5. Histórico
- Visualize todos os treinos
- **Exporte em CSV** (abre no Obsidian!)

### 6. Configurações
- Registre seus 1RMs (Squat, Bench, Deadlift)
- Veja backups
- Limpe dados se necessário

---

## 💾 Dados em CSV

Quando você exporta um treino, fica assim (compatível com Obsidian):

```csv
WORKOUTS
Date,Block,Exercise,Weight(kg),Reps,Sets,RPE,Tags,Notes
2026-02-02,Bloco1,Squat,150,5,3,8,"pesado,volume","Bom treino"
2026-02-02,Bloco1,Bench Press,100,6,4,7,"volume","Sentindo forte"

1RM RECORDS
Date,Exercise,Weight(kg),Notes
2026-01-15,Squat,180,"PR novo!"
2026-01-15,Bench Press,130,"Melhor que esperava"
2026-01-15,Deadlift,220,"Fácil demais"
```

---

## 🔧 Troubleshooting

### App não conecta
- Certifique-se que celular e PC estão na mesma rede WiFi
- Reinicie o Expo Go
- Execute `expo start` novamente

### Dados não salvam
- Verifique espaço no celular
- Tente limpar cache do Expo Go
- Reinstale o app

### RPE não calcula
- Registre um 1RM primeiro em Configurações
- O RPE usa seu 1RM mais recente

### Gráficos não aparecem
- Adicione mais treinos (precisa de pelo menos 2)
- Verifique se os treinos têm datas diferentes

---

## 📱 Especificações

- **Plataforma**: Android (iOS com pequenos ajustes)
- **Tamanho**: ~50-80 MB
- **Offline**: 100% funcional sem internet
- **Armazenamento**: Local no celular
- **Sincronização**: Via arquivo CSV

---

## 🎨 Design

- **Cores**: Roxo vibrante (#8B5CF6) + Preto profundo (#0F0F1E)
- **Tipografia**: Letras médias elegantes
- **Vibe**: Dark Zone - dá vontade de treinar!

---

## 📞 Suporte

Se tiver dúvidas:
1. Verifique se o Expo Go está atualizado
2. Tente limpar cache: `expo start --clear`
3. Reinstale dependências: `rm -rf node_modules && npm install`

---

## 🎉 Pronto!

Seu **Powerlifting Tracker Pro** está completo e pronto para usar!

**Próximos passos:**
1. ✅ Instale Expo Go no celular
2. ✅ Execute `expo start` no PC
3. ✅ Escaneie o QR code
4. ✅ Comece a registrar seus treinos!

**Boa sorte nos treinos! 💪🔥**
