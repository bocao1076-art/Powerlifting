import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { LineChart } from 'react-native-chart-kit';
import { colors, typography, spacing, borderRadius } from '../theme/colors';
import { Workout } from '../types';

interface EvolutionChartProps {
  workouts: Workout[];
  exerciseName: string;
}

export const EvolutionChart: React.FC<EvolutionChartProps> = ({ workouts, exerciseName }) => {
  // Filter workouts for the specific exercise
  const exerciseWorkouts = workouts
    .flatMap(w => w.sets.filter(s => s.exerciseName === exerciseName).map(s => ({ ...s, date: w.date })))
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(-10); // Last 10 workouts

  if (exerciseWorkouts.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>Sem dados para {exerciseName}</Text>
      </View>
    );
  }

  // Prepare chart data
  const labels = exerciseWorkouts.map(w => 
    new Date(w.date).toLocaleDateString('pt-BR', { month: 'short', day: 'numeric' })
  );
  
  const weights = exerciseWorkouts.map(w => w.weight);
  const maxWeight = Math.max(...weights);
  const minWeight = Math.min(...weights);

  const chartData = {
    labels,
    datasets: [
      {
        data: weights,
        color: (opacity = 1) => `rgba(139, 92, 246, ${opacity})`, // Purple
        strokeWidth: 2,
      },
    ],
  };

  const screenWidth = Dimensions.get('window').width;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{exerciseName}</Text>
        <View style={styles.statsRow}>
          <View style={styles.stat}>
            <Text style={styles.statLabel}>Máx</Text>
            <Text style={styles.statValue}>{maxWeight.toFixed(1)}kg</Text>
          </View>
          <View style={styles.stat}>
            <Text style={styles.statLabel}>Mín</Text>
            <Text style={styles.statValue}>{minWeight.toFixed(1)}kg</Text>
          </View>
          <View style={styles.stat}>
            <Text style={styles.statLabel}>Média</Text>
            <Text style={styles.statValue}>
              {(weights.reduce((a, b) => a + b, 0) / weights.length).toFixed(1)}kg
            </Text>
          </View>
        </View>
      </View>

      <LineChart
        data={chartData}
        width={screenWidth - spacing.lg * 2}
        height={220}
        chartConfig={{
          backgroundColor: colors.surface,
          backgroundGradientFrom: colors.surface,
          backgroundGradientTo: colors.surface,
          decimalPlaces: 0,
          color: (opacity = 1) => `rgba(176, 173, 204, ${opacity})`,
          labelColor: (opacity = 1) => `rgba(176, 173, 204, ${opacity})`,
          style: {
            borderRadius: borderRadius.md,
          },
          propsForDots: {
            r: '5',
            strokeWidth: '2',
            stroke: colors.primary,
          },
        }}
        bezier
        style={styles.chart}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.lg,
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
  },
  header: {
    marginBottom: spacing.lg,
  },
  title: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.md,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  stat: {
    alignItems: 'center',
  },
  statLabel: {
    fontSize: typography.fontSize.xs,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
    fontWeight: '500',
  },
  statValue: {
    fontSize: typography.fontSize.base,
    fontWeight: '700',
    color: colors.primary,
  },
  chart: {
    borderRadius: borderRadius.md,
    marginVertical: spacing.md,
  },
  emptyContainer: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
    height: 150,
  },
  emptyText: {
    color: colors.textMuted,
    fontSize: typography.fontSize.sm,
  },
});
