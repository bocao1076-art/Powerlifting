import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Modal,
  FlatList,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppData, Workout } from '../types';
import { EvolutionChart } from '../components/EvolutionChart';
import { colors, spacing, typography, borderRadius } from '../theme/colors';

interface AnalysisScreenProps {
  appData: AppData | null;
  onDataChange: () => void;
}

const AnalysisScreen: React.FC<AnalysisScreenProps> = ({ appData, onDataChange }) => {
  const [selectedBlock, setSelectedBlock] = useState<string>('all');
  const [showBlockModal, setShowBlockModal] = useState(false);

  const filteredWorkouts = useMemo(() => {
    if (!appData) return [];
    if (selectedBlock === 'all') return appData.workouts;
    return appData.workouts.filter(w => w.blockId === selectedBlock);
  }, [appData, selectedBlock]);

  // Get main lifts for analysis
  const mainLifts = ['Squat', 'Bench Press', 'Deadlift'];
  
  // Calculate block statistics
  const blockStats = useMemo(() => {
    if (filteredWorkouts.length === 0) return null;

    const totalVolume = filteredWorkouts.reduce((sum, w) => {
      return sum + w.sets.reduce((setSum, s) => setSum + (s.weight * s.reps * s.sets), 0);
    }, 0);

    const avgIntensity = filteredWorkouts.reduce((sum, w) => {
      const workoutIntensity = w.sets.reduce((setSum, s) => setSum + s.rpe, 0) / (w.sets.length || 1);
      return sum + workoutIntensity;
    }, 0) / filteredWorkouts.length;

    const totalSets = filteredWorkouts.reduce((sum, w) => sum + w.sets.length, 0);

    return {
      workoutCount: filteredWorkouts.length,
      totalVolume: totalVolume.toFixed(0),
      avgIntensity: avgIntensity.toFixed(1),
      totalSets,
    };
  }, [filteredWorkouts]);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Análise de Evolução</Text>
          <TouchableOpacity
            style={styles.filterButton}
            onPress={() => setShowBlockModal(true)}
          >
            <Ionicons name="filter" size={18} color={colors.background} />
            <Text style={styles.filterButtonText}>
              {selectedBlock === 'all' ? 'Todos' : 'Bloco'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Block Statistics */}
        {blockStats && (
          <View style={styles.statsContainer}>
            <StatCard
              label="Treinos"
              value={blockStats.workoutCount}
              icon="📋"
            />
            <StatCard
              label="Volume Total"
              value={`${blockStats.totalVolume}kg`}
              icon="📊"
            />
            <StatCard
              label="RPE Médio"
              value={blockStats.avgIntensity}
              icon="⚡"
            />
            <StatCard
              label="Séries"
              value={blockStats.totalSets}
              icon="🔄"
            />
          </View>
        )}

        {/* Evolution Charts */}
        <View style={styles.chartsSection}>
          <Text style={styles.sectionTitle}>Evolução dos Principais Movimentos</Text>
          {mainLifts.map((lift, index) => (
            <EvolutionChart
              key={index}
              workouts={filteredWorkouts}
              exerciseName={lift}
            />
          ))}
        </View>

        {/* Workout Distribution */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Distribuição de Treinos</Text>
          <View style={styles.distributionContainer}>
            {filteredWorkouts.length > 0 ? (
              <>
                <DistributionItem
                  label="Treinos Pesados (RPE 8-10)"
                  count={filteredWorkouts.filter(w =>
                    w.sets.some(s => s.rpe >= 8)
                  ).length}
                  color={colors.error}
                />
                <DistributionItem
                  label="Treinos Moderados (RPE 6-7)"
                  count={filteredWorkouts.filter(w =>
                    w.sets.some(s => s.rpe >= 6 && s.rpe < 8)
                  ).length}
                  color={colors.warning}
                />
                <DistributionItem
                  label="Treinos Leves (RPE 1-5)"
                  count={filteredWorkouts.filter(w =>
                    w.sets.every(s => s.rpe < 6)
                  ).length}
                  color={colors.success}
                />
              </>
            ) : (
              <Text style={styles.emptyText}>Nenhum treino para análise</Text>
            )}
          </View>
        </View>

        {/* Insights */}
        <View style={styles.insightsSection}>
          <Text style={styles.sectionTitle}>Insights</Text>
          {filteredWorkouts.length > 0 ? (
            <>
              <InsightCard
                icon="🎯"
                title="Exercício Mais Feito"
                description={getMostFrequentExercise(filteredWorkouts)}
              />
              <InsightCard
                icon="💪"
                title="Carga Máxima"
                description={`${getMaxWeight(filteredWorkouts).toFixed(1)}kg`}
              />
              <InsightCard
                icon="📈"
                title="Tendência"
                description={getTrend(filteredWorkouts)}
              />
            </>
          ) : (
            <Text style={styles.emptyText}>Sem dados para análise</Text>
          )}
        </View>
      </ScrollView>

      {/* Block Filter Modal */}
      <Modal
        visible={showBlockModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowBlockModal(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Filtrar por Bloco</Text>
              <TouchableOpacity onPress={() => setShowBlockModal(false)}>
                <Ionicons name="close" size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={[
                styles.blockOption,
                selectedBlock === 'all' && styles.blockOptionSelected,
              ]}
              onPress={() => {
                setSelectedBlock('all');
                setShowBlockModal(false);
              }}
            >
              <Text style={styles.blockOptionText}>Todos os Treinos</Text>
            </TouchableOpacity>

            {appData?.blocks.map((block, index) => (
              <TouchableOpacity
                key={index}
                style={[
                  styles.blockOption,
                  selectedBlock === block.id && styles.blockOptionSelected,
                ]}
                onPress={() => {
                  setSelectedBlock(block.id);
                  setShowBlockModal(false);
                }}
              >
                <Text style={styles.blockOptionText}>{block.name}</Text>
                <Text style={styles.blockOptionSubtext}>
                  Semana {block.weekNumber} • {block.blockType}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

interface StatCardProps {
  label: string;
  value: string | number;
  icon: string;
}

const StatCard: React.FC<StatCardProps> = ({ label, value, icon }) => (
  <View style={styles.statCard}>
    <Text style={styles.statIcon}>{icon}</Text>
    <Text style={styles.statLabel}>{label}</Text>
    <Text style={styles.statValue}>{value}</Text>
  </View>
);

interface DistributionItemProps {
  label: string;
  count: number;
  color: string;
}

const DistributionItem: React.FC<DistributionItemProps> = ({ label, count, color }) => (
  <View style={styles.distributionItem}>
    <View style={[styles.distributionDot, { backgroundColor: color }]} />
    <Text style={styles.distributionLabel}>{label}</Text>
    <Text style={styles.distributionCount}>{count}</Text>
  </View>
);

interface InsightCardProps {
  icon: string;
  title: string;
  description: string;
}

const InsightCard: React.FC<InsightCardProps> = ({ icon, title, description }) => (
  <View style={styles.insightCard}>
    <Text style={styles.insightIcon}>{icon}</Text>
    <View style={styles.insightContent}>
      <Text style={styles.insightTitle}>{title}</Text>
      <Text style={styles.insightDescription}>{description}</Text>
    </View>
  </View>
);

// Helper functions
const getMostFrequentExercise = (workouts: Workout[]): string => {
  const exerciseCounts: Record<string, number> = {};
  workouts.forEach(w => {
    w.sets.forEach(s => {
      exerciseCounts[s.exerciseName] = (exerciseCounts[s.exerciseName] || 0) + 1;
    });
  });
  const mostFrequent = Object.entries(exerciseCounts).sort((a, b) => b[1] - a[1])[0];
  return mostFrequent ? `${mostFrequent[0]} (${mostFrequent[1]}x)` : 'N/A';
};

const getMaxWeight = (workouts: Workout[]): number => {
  let max = 0;
  workouts.forEach(w => {
    w.sets.forEach(s => {
      if (s.weight > max) max = s.weight;
    });
  });
  return max;
};

const getTrend = (workouts: Workout[]): string => {
  if (workouts.length < 2) return 'Sem dados';
  
  const firstHalf = workouts.slice(0, Math.floor(workouts.length / 2));
  const secondHalf = workouts.slice(Math.floor(workouts.length / 2));
  
  const firstAvg = firstHalf.reduce((sum, w) => sum + w.sets.reduce((s, set) => s + set.weight, 0), 0) / firstHalf.length;
  const secondAvg = secondHalf.reduce((sum, w) => sum + w.sets.reduce((s, set) => s + set.weight, 0), 0) / secondHalf.length;
  
  const diff = ((secondAvg - firstAvg) / firstAvg * 100).toFixed(1);
  return secondAvg > firstAvg ? `📈 +${diff}%` : `📉 ${diff}%`;
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.lg,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  headerTitle: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700',
    color: colors.text,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    gap: spacing.sm,
  },
  filterButtonText: {
    color: colors.background,
    fontWeight: '600',
    fontSize: typography.fontSize.sm,
  },
  statsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.md,
    marginBottom: spacing.xl,
  },
  statCard: {
    flex: 1,
    minWidth: '48%',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    alignItems: 'center',
    borderTopWidth: 2,
    borderTopColor: colors.primary,
  },
  statIcon: {
    fontSize: 24,
    marginBottom: spacing.sm,
  },
  statLabel: {
    fontSize: typography.fontSize.xs,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
    fontWeight: '500',
  },
  statValue: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700',
    color: colors.primary,
  },
  chartsSection: {
    marginBottom: spacing.xl,
  },
  sectionTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.lg,
  },
  section: {
    marginBottom: spacing.xl,
  },
  distributionContainer: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
  },
  distributionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  distributionDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: spacing.md,
  },
  distributionLabel: {
    flex: 1,
    fontSize: typography.fontSize.sm,
    color: colors.text,
  },
  distributionCount: {
    fontSize: typography.fontSize.base,
    fontWeight: '700',
    color: colors.primary,
  },
  insightsSection: {
    marginBottom: spacing.xl,
  },
  insightCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
  },
  insightIcon: {
    fontSize: 24,
    marginRight: spacing.lg,
  },
  insightContent: {
    flex: 1,
  },
  insightTitle: {
    fontSize: typography.fontSize.base,
    fontWeight: '600',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  insightDescription: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
  },
  emptyText: {
    color: colors.textMuted,
    textAlign: 'center',
    paddingVertical: spacing.lg,
    fontSize: typography.fontSize.sm,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: borderRadius.xl,
    borderTopRightRadius: borderRadius.xl,
    paddingTop: spacing.lg,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700',
    color: colors.text,
  },
  blockOption: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  blockOptionSelected: {
    backgroundColor: colors.primary + '20',
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
  },
  blockOptionText: {
    color: colors.text,
    fontSize: typography.fontSize.base,
    fontWeight: '600',
    marginBottom: spacing.sm,
  },
  blockOptionSubtext: {
    color: colors.textSecondary,
    fontSize: typography.fontSize.xs,
  },
});

export default AnalysisScreen;
