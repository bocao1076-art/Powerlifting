import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppData, Workout, OneRMRecord, Exercise, TrainingBlock } from '../types';

const STORAGE_KEY = '@powerlifting_tracker';

const defaultAppData: AppData = {
  exercises: [
    // Main lifts
    { id: '1', name: 'Squat', category: 'squat', isCustom: false },
    { id: '2', name: 'Bench Press', category: 'bench', isCustom: false },
    { id: '3', name: 'Deadlift', category: 'deadlift', isCustom: false },
    
    // Squat accessories
    { id: '4', name: 'Front Squat', category: 'accessory', isCustom: false },
    { id: '5', name: 'Leg Press', category: 'accessory', isCustom: false },
    { id: '6', name: 'Hack Squat', category: 'accessory', isCustom: false },
    { id: '7', name: 'Leg Curl', category: 'accessory', isCustom: false },
    { id: '8', name: 'Leg Extension', category: 'accessory', isCustom: false },
    
    // Bench accessories
    { id: '9', name: 'Incline Bench Press', category: 'accessory', isCustom: false },
    { id: '10', name: 'Dumbbell Press', category: 'accessory', isCustom: false },
    { id: '11', name: 'Close Grip Bench', category: 'accessory', isCustom: false },
    { id: '12', name: 'Tricep Dips', category: 'accessory', isCustom: false },
    { id: '13', name: 'Tricep Rope', category: 'accessory', isCustom: false },
    
    // Deadlift accessories
    { id: '14', name: 'Deficit Deadlift', category: 'accessory', isCustom: false },
    { id: '15', name: 'Sumo Deadlift', category: 'accessory', isCustom: false },
    { id: '16', name: 'Rack Pull', category: 'accessory', isCustom: false },
    { id: '17', name: 'Romanian Deadlift', category: 'accessory', isCustom: false },
    { id: '18', name: 'Barbell Row', category: 'accessory', isCustom: false },
    { id: '19', name: 'Pendlay Row', category: 'accessory', isCustom: false },
  ],
  workouts: [],
  blocks: [],
  oneRMs: [],
  lastUpdated: new Date().toISOString(),
};

export const loadAppData = async (): Promise<AppData> => {
  try {
    const data = await AsyncStorage.getItem(STORAGE_KEY);
    if (data) {
      return JSON.parse(data);
    }
    return defaultAppData;
  } catch (error) {
    console.error('Error loading app data:', error);
    return defaultAppData;
  }
};

export const saveAppData = async (data: AppData): Promise<void> => {
  try {
    data.lastUpdated = new Date().toISOString();
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving app data:', error);
  }
};

export const addWorkout = async (workout: Workout): Promise<void> => {
  const data = await loadAppData();
  data.workouts.push(workout);
  await saveAppData(data);
};

export const addOneRM = async (record: OneRMRecord): Promise<void> => {
  const data = await loadAppData();
  data.oneRMs.push(record);
  await saveAppData(data);
};

export const addExercise = async (exercise: Exercise): Promise<void> => {
  const data = await loadAppData();
  data.exercises.push(exercise);
  await saveAppData(data);
};

export const addTrainingBlock = async (block: TrainingBlock): Promise<void> => {
  const data = await loadAppData();
  data.blocks.push(block);
  await saveAppData(data);
};

export const updateTrainingBlock = async (blockId: string, updates: Partial<TrainingBlock>): Promise<void> => {
  const data = await loadAppData();
  const blockIndex = data.blocks.findIndex(b => b.id === blockId);
  if (blockIndex !== -1) {
    data.blocks[blockIndex] = { ...data.blocks[blockIndex], ...updates };
    await saveAppData(data);
  }
};

export const deleteWorkout = async (workoutId: string): Promise<void> => {
  const data = await loadAppData();
  data.workouts = data.workouts.filter(w => w.id !== workoutId);
  await saveAppData(data);
};

export const deleteOneRM = async (recordId: string): Promise<void> => {
  const data = await loadAppData();
  data.oneRMs = data.oneRMs.filter(r => r.id !== recordId);
  await saveAppData(data);
};

export const getWorkoutsByDate = async (date: string): Promise<Workout[]> => {
  const data = await loadAppData();
  return data.workouts.filter(w => w.date === date);
};

export const getWorkoutsByBlock = async (blockId: string): Promise<Workout[]> => {
  const data = await loadAppData();
  return data.workouts.filter(w => w.blockId === blockId);
};

export const getLatestOneRM = async (exerciseId: string): Promise<OneRMRecord | null> => {
  const data = await loadAppData();
  const records = data.oneRMs
    .filter(r => r.exerciseId === exerciseId)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  return records.length > 0 ? records[0] : null;
};

export const clearAllData = async (): Promise<void> => {
  try {
    await AsyncStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error('Error clearing data:', error);
  }
};
