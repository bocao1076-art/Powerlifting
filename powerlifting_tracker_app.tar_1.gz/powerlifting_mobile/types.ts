export interface Exercise {
  id: string;
  name: string;
  category: 'squat' | 'bench' | 'deadlift' | 'accessory';
  isCustom: boolean;
}

export interface WorkoutSet {
  id: string;
  exerciseId: string;
  exerciseName: string;
  weight: number;
  reps: number;
  sets: number;
  rpe: number;
  tags: string[];
  notes: string;
}

export interface Workout {
  id: string;
  date: string;
  blockId: string;
  sets: WorkoutSet[];
  notes: string;
  createdAt: string;
}

export interface TrainingBlock {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  weekNumber: number;
  blockType: 'accumulation' | 'intensification' | 'realization' | 'deload';
  days: TrainingDay[];
}

export interface TrainingDay {
  id: string;
  dayOfWeek: number; // 0-6 (Sunday-Saturday)
  dayName: string;
  exerciseIds: string[];
  type: 'heavy' | 'volume' | 'light' | 'technique';
  notes: string;
}

export interface OneRMRecord {
  id: string;
  exerciseId: string;
  exerciseName: string;
  weight: number;
  date: string;
  notes: string;
}

export interface AppData {
  exercises: Exercise[];
  workouts: Workout[];
  blocks: TrainingBlock[];
  oneRMs: OneRMRecord[];
  lastUpdated: string;
}
