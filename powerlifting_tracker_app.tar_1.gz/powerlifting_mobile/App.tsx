import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppData } from './types';
import { loadAppData } from './utils/storage';
import { colors } from './theme/colors';

// Screens
import DashboardScreen from './screens/DashboardScreen';
import NewWorkoutScreen from './screens/NewWorkoutScreen';
import HistoryScreen from './screens/HistoryScreen';
import BlocksScreen from './screens/BlocksScreen';
import AnalysisScreen from './screens/AnalysisScreen';
import SettingsScreen from './screens/SettingsScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  const [appData, setAppData] = useState<AppData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const data = await loadAppData();
      setAppData(data);
    } catch (error) {
      console.error('Error loading app data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background }}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarStyle: {
            backgroundColor: colors.surface,
            borderTopColor: colors.border,
            borderTopWidth: 1,
            paddingBottom: 8,
            paddingTop: 8,
            height: 70,
          },
          tabBarLabelStyle: {
            fontSize: 12,
            marginTop: 4,
            color: colors.text,
          },
          tabBarActiveTintColor: colors.primary,
          tabBarInactiveTintColor: colors.textMuted,
          tabBarIcon: ({ focused, color, size }) => {
            let iconName: any;

            if (route.name === 'Dashboard') {
              iconName = focused ? 'home' : 'home-outline';
            } else if (route.name === 'NewWorkout') {
              iconName = focused ? 'add-circle' : 'add-circle-outline';
            } else if (route.name === 'History') {
              iconName = focused ? 'list' : 'list-outline';
            } else if (route.name === 'Blocks') {
              iconName = focused ? 'calendar' : 'calendar-outline';
            } else if (route.name === 'Analysis') {
              iconName = focused ? 'bar-chart' : 'bar-chart-outline';
            } else if (route.name === 'Settings') {
              iconName = focused ? 'settings' : 'settings-outline';
            }

            return <Ionicons name={iconName} size={size} color={color} />;
          },
        })}
      >
        <Tab.Screen
          name="Dashboard"
          options={{ title: 'Dashboard' }}
          children={() => <DashboardScreen appData={appData} onDataChange={loadData} />}
        />
        <Tab.Screen
          name="NewWorkout"
          options={{ title: 'Novo Treino' }}
          children={() => <NewWorkoutScreen appData={appData} onDataChange={loadData} />}
        />
        <Tab.Screen
          name="History"
          options={{ title: 'Histórico' }}
          children={() => <HistoryScreen appData={appData} onDataChange={loadData} />}
        />
        <Tab.Screen
          name="Blocks"
          options={{ title: 'Blocos' }}
          children={() => <BlocksScreen appData={appData} onDataChange={loadData} />}
        />
        <Tab.Screen
          name="Analysis"
          options={{ title: 'Análise' }}
          children={() => <AnalysisScreen appData={appData} onDataChange={loadData} />}
        />
        <Tab.Screen
          name="Settings"
          options={{ title: 'Configurações' }}
          children={() => <SettingsScreen appData={appData} onDataChange={loadData} />}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
