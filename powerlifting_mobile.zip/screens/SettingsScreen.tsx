import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Alert,
  Modal,
  TextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { v4 as uuidv4 } from 'uuid';
import { AppData, OneRMRecord } from '../types';
import { addOneRM, clearAllData } from '../utils/storage';
import { exportToCSV, shareCSV, getAllBackupFiles } from '../utils/csvManager';
import { colors, spacing, typography, borderRadius } from '../theme/colors';

interface SettingsScreenProps {
  appData: AppData | null;
  onDataChange: () => void;
}

const SettingsScreen: React.FC<SettingsScreenProps> = ({ appData, onDataChange }) => {
  const [showOneRMModal, setShowOneRMModal] = useState(false);
  const [showBackupsModal, setShowBackupsModal] = useState(false);
  const [oneRMExercise, setOneRMExercise] = useState('');
  const [oneRMWeight, setOneRMWeight] = useState('');
  const [backupFiles, setBackupFiles] = useState<any[]>([]);

  const handleAddOneRM = async () => {
    if (!oneRMExercise || !oneRMWeight) {
      Alert.alert('Erro', 'Preencha todos os campos');
      return;
    }

    const record: OneRMRecord = {
      id: uuidv4(),
      exerciseId: oneRMExercise,
      exerciseName: appData?.exercises.find(e => e.id === oneRMExercise)?.name || '',
      weight: parseFloat(oneRMWeight),
      date: new Date().toISOString().split('T')[0],
      notes: '',
    };

    try {
      await addOneRM(record);
      Alert.alert('Sucesso', '1RM registrado com sucesso!');
      setOneRMExercise('');
      setOneRMWeight('');
      setShowOneRMModal(false);
      onDataChange();
    } catch (error) {
      Alert.alert('Erro', 'Falha ao registrar 1RM');
    }
  };

  const handleExportData = async () => {
    if (!appData) return;
    try {
      const filepath = await exportToCSV(appData);
      await shareCSV(filepath);
    } catch (error) {
      Alert.alert('Erro', 'Falha ao exportar dados');
    }
  };

  const handleViewBackups = async () => {
    try {
      const files = await getAllBackupFiles();
      setBackupFiles(files);
      setShowBackupsModal(true);
    } catch (error) {
      Alert.alert('Erro', 'Falha ao carregar backups');
    }
  };

  const handleClearData = () => {
    Alert.alert(
      'Limpar Dados',
      'Tem certeza? Esta ação não pode ser desfeita.',
      [
        { text: 'Cancelar', onPress: () => {} },
        {
          text: 'Limpar',
          onPress: async () => {
            try {
              await clearAllData();
              Alert.alert('Sucesso', 'Todos os dados foram limpos');
              onDataChange();
            } catch (error) {
              Alert.alert('Erro', 'Falha ao limpar dados');
            }
          },
          style: 'destructive',
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>⚙️ Configurações</Text>
        </View>

        {/* 1RM Management */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Gerenciar 1RM</Text>
          <TouchableOpacity
            style={styles.settingButton}
            onPress={() => setShowOneRMModal(true)}
          >
            <View style={styles.settingButtonContent}>
              <Ionicons name="add-circle" size={24} color={colors.primary} />
              <View style={styles.settingButtonText}>
                <Text style={styles.settingButtonTitle}>Adicionar 1RM</Text>
                <Text style={styles.settingButtonSubtitle}>Registre seus máximos</Text>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.textMuted} />
          </TouchableOpacity>

          {appData && appData.oneRMs.length > 0 && (
            <View style={styles.oneRMList}>
              <Text style={styles.oneRMListTitle}>Seus 1RMs Recentes:</Text>
              {appData.oneRMs
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .slice(0, 5)
                .map((record, index) => (
                  <View key={index} style={styles.oneRMItem}>
                    <Text style={styles.oneRMItemName}>{record.exerciseName}</Text>
                    <Text style={styles.oneRMItemValue}>{record.weight}kg</Text>
                    <Text style={styles.oneRMItemDate}>
                      {new Date(record.date).toLocaleDateString('pt-BR')}
                    </Text>
                  </View>
                ))}
            </View>
          )}
        </View>

        {/* Data Management */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Gerenciar Dados</Text>

          <TouchableOpacity style={styles.settingButton} onPress={handleExportData}>
            <View style={styles.settingButtonContent}>
              <Ionicons name="download" size={24} color={colors.primary} />
              <View style={styles.settingButtonText}>
                <Text style={styles.settingButtonTitle}>Exportar CSV</Text>
                <Text style={styles.settingButtonSubtitle}>Baixe seus treinos</Text>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.textMuted} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingButton} onPress={handleViewBackups}>
            <View style={styles.settingButtonContent}>
              <Ionicons name="folder" size={24} color={colors.primary} />
              <View style={styles.settingButtonText}>
                <Text style={styles.settingButtonTitle}>Ver Backups</Text>
                <Text style={styles.settingButtonSubtitle}>
                  {backupFiles.length} arquivos
                </Text>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.textMuted} />
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Sobre o App</Text>

          <View style={styles.infoBox}>
            <Text style={styles.infoBoxTitle}>Powerlifting Tracker Pro</Text>
            <Text style={styles.infoBoxText}>Versão 1.0.0</Text>
            <Text style={styles.infoBoxText}>Dark Zone Edition</Text>
            <Text style={styles.infoBoxDescription}>
              Seu companheiro perfeito para rastreamento de treinos de powerlifting com design
              dark zone roxo e preto.
            </Text>
          </View>

          <View style={styles.statsBox}>
            <StatItem label="Total de Treinos" value={appData?.workouts.length || 0} />
            <StatItem label="Blocos" value={appData?.blocks.length || 0} />
            <StatItem label="1RMs Registrados" value={appData?.oneRMs.length || 0} />
            <StatItem label="Exercícios" value={appData?.exercises.length || 0} />
          </View>
        </View>

        {/* Danger Zone */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, styles.dangerTitle]}>Zona de Perigo</Text>

          <TouchableOpacity
            style={[styles.settingButton, styles.dangerButton]}
            onPress={handleClearData}
          >
            <View style={styles.settingButtonContent}>
              <Ionicons name="trash" size={24} color={colors.error} />
              <View style={styles.settingButtonText}>
                <Text style={[styles.settingButtonTitle, styles.dangerText]}>
                  Limpar Todos os Dados
                </Text>
                <Text style={styles.settingButtonSubtitle}>Não pode ser desfeito</Text>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.error} />
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Add 1RM Modal */}
      <Modal
        visible={showOneRMModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowOneRMModal(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Adicionar 1RM</Text>
              <TouchableOpacity onPress={() => setShowOneRMModal(false)}>
                <Ionicons name="close" size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            <View style={styles.modalBody}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Exercício</Text>
                <TouchableOpacity style={styles.selectInput}>
                  <Text style={styles.selectInputText}>
                    {oneRMExercise
                      ? appData?.exercises.find(e => e.id === oneRMExercise)?.name
                      : 'Selecione um exercício'}
                  </Text>
                </TouchableOpacity>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Peso (kg)</Text>
                <TextInput
                  style={styles.input}
                  placeholder="0"
                  placeholderTextColor={colors.textMuted}
                  keyboardType="decimal-pad"
                  value={oneRMWeight}
                  onChangeText={setOneRMWeight}
                />
              </View>

              <TouchableOpacity style={styles.saveButton} onPress={handleAddOneRM}>
                <Ionicons name="checkmark-circle" size={24} color={colors.background} />
                <Text style={styles.saveButtonText}>Registrar 1RM</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Backups Modal */}
      <Modal
        visible={showBackupsModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowBackupsModal(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Backups</Text>
              <TouchableOpacity onPress={() => setShowBackupsModal(false)}>
                <Ionicons name="close" size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            <View style={styles.modalBody}>
              {backupFiles.length > 0 ? (
                backupFiles.map((file, index) => (
                  <View key={index} style={styles.backupItem}>
                    <View style={styles.backupInfo}>
                      <Text style={styles.backupName}>{file.name}</Text>
                      <Text style={styles.backupSize}>
                        {(file.size / 1024).toFixed(2)} KB
                      </Text>
                    </View>
                  </View>
                ))
              ) : (
                <Text style={styles.emptyText}>Nenhum backup encontrado</Text>
              )}
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

interface StatItemProps {
  label: string;
  value: number;
}

const StatItem: React.FC<StatItemProps> = ({ label, value }) => (
  <View style={styles.statItem}>
    <Text style={styles.statLabel}>{label}</Text>
    <Text style={styles.statValue}>{value}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.lg,
  },
  header: {
    marginBottom: spacing.xl,
  },
  headerTitle: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700',
    color: colors.text,
  },
  section: {
    marginBottom: spacing.xl,
  },
  sectionTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.md,
  },
  dangerTitle: {
    color: colors.error,
  },
  settingButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  dangerButton: {
    borderColor: colors.error,
  },
  settingButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: spacing.lg,
  },
  settingButtonText: {
    flex: 1,
  },
  settingButtonTitle: {
    fontSize: typography.fontSize.base,
    fontWeight: '600',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  dangerText: {
    color: colors.error,
  },
  settingButtonSubtitle: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
  },
  oneRMList: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginTop: spacing.md,
  },
  oneRMListTitle: {
    fontSize: typography.fontSize.sm,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: spacing.md,
  },
  oneRMItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  oneRMItemName: {
    fontSize: typography.fontSize.base,
    color: colors.text,
    fontWeight: '500',
  },
  oneRMItemValue: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700',
    color: colors.primary,
  },
  oneRMItemDate: {
    fontSize: typography.fontSize.xs,
    color: colors.textSecondary,
  },
  infoBox: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderLeftWidth: 4,
    borderLeftColor: colors.primary,
  },
  infoBoxTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  infoBoxText: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  infoBoxDescription: {
    fontSize: typography.fontSize.sm,
    color: colors.text,
    lineHeight: 20,
    marginTop: spacing.md,
  },
  statsBox: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.md,
  },
  statItem: {
    flex: 1,
    minWidth: '45%',
    alignItems: 'center',
    paddingVertical: spacing.md,
  },
  statLabel: {
    fontSize: typography.fontSize.xs,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  statValue: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700',
    color: colors.primary,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: borderRadius.xl,
    borderTopRightRadius: borderRadius.xl,
    paddingTop: spacing.lg,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700',
    color: colors.text,
  },
  modalBody: {
    padding: spacing.lg,
  },
  inputGroup: {
    marginBottom: spacing.lg,
  },
  inputLabel: {
    fontSize: typography.fontSize.sm,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: spacing.md,
  },
  selectInput: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  selectInputText: {
    color: colors.text,
    fontSize: typography.fontSize.base,
  },
  input: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    color: colors.text,
    fontSize: typography.fontSize.base,
    borderWidth: 1,
    borderColor: colors.border,
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.lg,
    gap: spacing.md,
  },
  saveButtonText: {
    color: colors.background,
    fontSize: typography.fontSize.base,
    fontWeight: '600',
  },
  backupItem: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    padding: spacing.lg,
    marginBottom: spacing.md,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backupInfo: {
    flex: 1,
  },
  backupName: {
    color: colors.text,
    fontWeight: '600',
    marginBottom: spacing.sm,
  },
  backupSize: {
    color: colors.textSecondary,
    fontSize: typography.fontSize.sm,
  },
  emptyText: {
    color: colors.textMuted,
    textAlign: 'center',
    paddingVertical: spacing.lg,
  },
});

export default SettingsScreen;
