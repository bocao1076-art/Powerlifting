# Powerlifting Tracker Pro - Dark Zone Edition

Um aplicativo mobile nativo Android (APK) para rastreamento profissional de treinos de powerlifting com design dark zone roxo e preto.

## 🎯 Funcionalidades

✅ **Dashboard Inteligente** - Visualize seu total SBD, 1RMs e treinos recentes  
✅ **Registro de Treinos** - Adicione exercícios com cálculo automático de RPE  
✅ **Blocos de Treino** - Configure semanas pesadas, leves, volume e deload  
✅ **Gerenciamento de 1RM** - Rastreie seus máximos para Squat, Bench e Deadlift  
✅ **Histórico Completo** - Visualize todos os seus treinos com filtros  
✅ **Exportação CSV** - Baixe seus dados para usar no Obsidian ou Excel  
✅ **Armazenamento Local** - Funciona 100% offline, sem internet necessária  
✅ **Design Dark Zone** - Roxo vibrante + preto profundo para treinar com energia  

## 🚀 Como Compilar para APK

### Pré-requisitos
- Node.js 16+ instalado
- npm ou yarn
- Conta Expo (gratuita)

### Passos

1. **Instale as dependências:**
```bash
npm install
# ou
yarn install
```

2. **Instale o Expo CLI globalmente:**
```bash
npm install -g expo-cli
```

3. **Compile para Android:**
```bash
eas build --platform android
```

Ou, para desenvolvimento local:
```bash
expo start --android
```

### Gerar APK Manualmente

Se preferir gerar o APK sem usar EAS Build:

```bash
# Instale o EAS CLI
npm install -g eas-cli

# Configure o projeto
eas build:configure

# Compile
eas build --platform android --local
```

## 📱 Como Usar

### Dashboard
- Visualize seu total SBD atual
- Veja seus 1RMs mais recentes
- Acompanhe treinos recentes

### Novo Treino
1. Toque em "Novo Treino"
2. Selecione um bloco (opcional)
3. Adicione exercícios com peso, reps e séries
4. O RPE é calculado automaticamente
5. Salve o treino

### Blocos de Treino
- Crie blocos de acumulação, intensificação, realização ou deload
- Configure o número da semana
- Organize seus treinos por bloco

### Gerenciar 1RM
- Registre seus máximos em Configurações
- Visualize histórico de 1RMs
- Use para calcular RPE automaticamente

### Exportar Dados
- Toque em "Exportar CSV" no Histórico
- Compartilhe ou abra no Obsidian
- Formato: CSV compatível com Excel

## 📁 Estrutura de Dados

Os dados são salvos localmente em AsyncStorage e podem ser exportados em CSV:

```
WORKOUTS
Date,Block,Exercise,Weight(kg),Reps,Sets,RPE,Tags,Notes

1RM RECORDS
Date,Exercise,Weight(kg),Notes

EXERCISES
Name,Category,Custom
```

## 🎨 Design

- **Cores**: Roxo vibrante (#8B5CF6) + Preto profundo (#0F0F1E)
- **Tipografia**: Letras grandes e chamativas
- **Animações**: Transições suaves
- **Vibe**: Dark Zone - dá vontade de treinar!

## 🛠️ Tecnologias

- React Native 0.73
- Expo 50
- TypeScript
- React Navigation
- AsyncStorage
- Expo File System

## 📦 Tamanho do APK

~50-80 MB (dependendo de otimizações)

## 🔒 Privacidade

- Todos os dados são armazenados localmente
- Nenhuma informação é enviada para servidores
- Você tem controle total dos seus dados

## 🐛 Troubleshooting

### App não inicia
- Limpe o cache: `expo start --clear`
- Reinstale dependências: `rm -rf node_modules && npm install`

### Dados não salvam
- Verifique permissões de armazenamento no Android
- Tente limpar dados do app nas configurações

### RPE não calcula
- Registre um 1RM para o exercício primeiro
- O RPE usa seu 1RM mais recente

## 📞 Suporte

Para dúvidas ou bugs, verifique:
1. Se o app está atualizado
2. Se você tem espaço de armazenamento
3. Se as permissões estão concedidas

## 📄 Licença

MIT License - Use livremente!

---

**Powerlifting Tracker Pro** - Seu companheiro perfeito para dominar o powerlifting! 💪🔥
