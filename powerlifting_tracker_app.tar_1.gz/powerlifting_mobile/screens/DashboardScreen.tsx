import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppData, OneRMRecord, Workout } from '../types';
import { colors, spacing, typography, borderRadius } from '../theme/colors';

interface DashboardScreenProps {
  appData: AppData | null;
  onDataChange: () => void;
}

const DashboardScreen: React.FC<DashboardScreenProps> = ({ appData, onDataChange }) => {
  const [totalSBD, setTotalSBD] = useState<number>(0);
  const [squat1RM, setSquat1RM] = useState<OneRMRecord | null>(null);
  const [bench1RM, setBench1RM] = useState<OneRMRecord | null>(null);
  const [deadlift1RM, setDeadlift1RM] = useState<OneRMRecord | null>(null);
  const [recentWorkouts, setRecentWorkouts] = useState<Workout[]>([]);

  useEffect(() => {
    if (appData) {
      calculateMetrics();
    }
  }, [appData]);

  const calculateMetrics = () => {
    if (!appData) return;

    // Get latest 1RMs
    const squat = appData.oneRMs
      .filter(r => r.exerciseName === 'Squat')
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
    
    const bench = appData.oneRMs
      .filter(r => r.exerciseName === 'Bench Press')
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
    
    const deadlift = appData.oneRMs
      .filter(r => r.exerciseName === 'Deadlift')
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];

    setSquat1RM(squat || null);
    setBench1RM(bench || null);
    setDeadlift1RM(deadlift || null);

    const total = (squat?.weight || 0) + (bench?.weight || 0) + (deadlift?.weight || 0);
    setTotalSBD(total);

    // Get recent workouts
    const recent = appData.workouts
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 5);
    setRecentWorkouts(recent);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>💪 Powerlifting Tracker Pro</Text>
          <Text style={styles.headerSubtitle}>Dark Zone Edition</Text>
        </View>

        {/* Total SBD Card */}
        <View style={styles.totalCard}>
          <Text style={styles.totalLabel}>TOTAL SBD</Text>
          <Text style={styles.totalValue}>{totalSBD.toFixed(1)} kg</Text>
          <Text style={styles.totalSubtext}>Seu melhor total</Text>
        </View>

        {/* 1RM Cards */}
        <View style={styles.oneRMContainer}>
          <OneRMCard label="AGACHAMENTO" weight={squat1RM?.weight} icon="🦵" />
          <OneRMCard label="SUPINO" weight={bench1RM?.weight} icon="🏋️" />
          <OneRMCard label="TERRA" weight={deadlift1RM?.weight} icon="📦" />
        </View>

        {/* Recent Workouts */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Treinos Recentes</Text>
          {recentWorkouts.length > 0 ? (
            recentWorkouts.map((workout, index) => (
              <View key={index} style={styles.workoutItem}>
                <View style={styles.workoutDate}>
                  <Text style={styles.workoutDateText}>
                    {new Date(workout.date).toLocaleDateString('pt-BR')}
                  </Text>
                </View>
                <View style={styles.workoutInfo}>
                  <Text style={styles.workoutExercises}>
                    {workout.sets.length} exercícios • {workout.sets.reduce((sum, s) => sum + s.sets, 0)} séries
                  </Text>
                  <Text style={styles.workoutNotes}>{workout.notes || 'Sem notas'}</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color={colors.primary} />
              </View>
            ))
          ) : (
            <Text style={styles.emptyText}>Nenhum treino registrado ainda</Text>
          )}
        </View>

        {/* Quick Stats */}
        <View style={styles.statsContainer}>
          <StatCard label="Total de Treinos" value={appData?.workouts.length || 0} icon="📊" />
          <StatCard label="Blocos Ativos" value={appData?.blocks.length || 0} icon="📅" />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

interface OneRMCardProps {
  label: string;
  weight?: number;
  icon: string;
}

const OneRMCard: React.FC<OneRMCardProps> = ({ label, weight, icon }) => (
  <View style={styles.oneRMCard}>
    <Text style={styles.oneRMIcon}>{icon}</Text>
    <Text style={styles.oneRMLabel}>{label}</Text>
    <Text style={styles.oneRMValue}>{weight ? `${weight.toFixed(1)} kg` : '—'}</Text>
  </View>
);

interface StatCardProps {
  label: string;
  value: number;
  icon: string;
}

const StatCard: React.FC<StatCardProps> = ({ label, value, icon }) => (
  <View style={styles.statCard}>
    <Text style={styles.statIcon}>{icon}</Text>
    <Text style={styles.statLabel}>{label}</Text>
    <Text style={styles.statValue}>{value}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.lg,
  },
  header: {
    marginBottom: spacing.xl,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.sm,
    letterSpacing: 0.3,
  },
  headerSubtitle: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
  },
  totalCard: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.xl,
    marginBottom: spacing.xl,
    borderLeftWidth: 4,
    borderLeftColor: colors.primary,
    alignItems: 'center',
  },
  totalLabel: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    fontWeight: '600',
    letterSpacing: 1,
  },
  totalValue: {
    fontSize: typography.fontSize['3xl'],
    fontWeight: '700',
    color: colors.primary,
    marginVertical: spacing.md,
    letterSpacing: 0.5,
  },
  totalSubtext: {
    fontSize: typography.fontSize.sm,
    color: colors.textMuted,
  },
  oneRMContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: spacing.xl,
    gap: spacing.md,
  },
  oneRMCard: {
    flex: 1,
    backgroundColor: colors.surfaceLight,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    alignItems: 'center',
    borderTopWidth: 2,
    borderTopColor: colors.primary,
  },
  oneRMIcon: {
    fontSize: 28,
    marginBottom: spacing.sm,
  },
  oneRMLabel: {
    fontSize: typography.fontSize.xs,
    color: colors.textSecondary,
    fontWeight: '600',
    marginBottom: spacing.sm,
  },
  oneRMValue: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700',
    color: colors.primary,
  },
  section: {
    marginBottom: spacing.xl,
  },
  sectionTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.md,
  },
  workoutItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  workoutDate: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginRight: spacing.md,
  },
  workoutDateText: {
    color: colors.background,
    fontWeight: '600',
    fontSize: typography.fontSize.xs,
  },
  workoutInfo: {
    flex: 1,
  },
  workoutExercises: {
    color: colors.text,
    fontWeight: '600',
    fontSize: typography.fontSize.sm,
  },
  workoutNotes: {
    color: colors.textSecondary,
    fontSize: typography.fontSize.xs,
    marginTop: spacing.sm,
  },
  emptyText: {
    color: colors.textMuted,
    textAlign: 'center',
    paddingVertical: spacing.lg,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: spacing.md,
    marginBottom: spacing.xl,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.lg,
    alignItems: 'center',
  },
  statIcon: {
    fontSize: 24,
    marginBottom: spacing.sm,
  },
  statLabel: {
    fontSize: typography.fontSize.xs,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  statValue: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700',
    color: colors.primary,
  },
});

export default DashboardScreen;
