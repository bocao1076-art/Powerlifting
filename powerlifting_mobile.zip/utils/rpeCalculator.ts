// RPE table: reps x weight percentage relationships
const RPE_TABLE: Record<number, Record<number, number>> = {
  1: { 1: 100, 2: 102.5, 3: 105, 4: 107.5, 5: 110, 6: 112.5, 7: 115, 8: 117.5, 9: 120, 10: 122.5 },
  2: { 1: 97.5, 2: 100, 3: 102.5, 4: 105, 5: 107.5, 6: 110, 7: 112.5, 8: 115, 9: 117.5, 10: 120 },
  3: { 1: 95, 2: 97.5, 3: 100, 4: 102.5, 5: 105, 6: 107.5, 7: 110, 8: 112.5, 9: 115, 10: 117.5 },
  4: { 1: 92.5, 2: 95, 3: 97.5, 4: 100, 5: 102.5, 6: 105, 7: 107.5, 8: 110, 9: 112.5, 10: 115 },
  5: { 1: 90, 2: 92.5, 3: 95, 4: 97.5, 5: 100, 6: 102.5, 7: 105, 8: 107.5, 9: 110, 10: 112.5 },
  6: { 1: 87.5, 2: 90, 3: 92.5, 4: 95, 5: 97.5, 6: 100, 7: 102.5, 8: 105, 9: 107.5, 10: 110 },
  7: { 1: 85, 2: 87.5, 3: 90, 4: 92.5, 5: 95, 6: 97.5, 7: 100, 8: 102.5, 9: 105, 10: 107.5 },
  8: { 1: 82.5, 2: 85, 3: 87.5, 4: 90, 5: 92.5, 6: 95, 7: 97.5, 8: 100, 9: 102.5, 10: 105 },
  9: { 1: 80, 2: 82.5, 3: 85, 4: 87.5, 5: 90, 6: 92.5, 7: 95, 8: 97.5, 9: 100, 10: 102.5 },
  10: { 1: 77.5, 2: 80, 3: 82.5, 4: 85, 5: 87.5, 6: 90, 7: 92.5, 8: 95, 9: 97.5, 10: 100 },
};

export function calculateEstimated1RM(weight: number, reps: number): number {
  if (reps === 1) return weight;
  return weight * (1 + reps / 30);
}

export function calculateRPE(weight: number, reps: number, oneRM: number): number {
  if (reps < 1 || reps > 10) {
    return 0;
  }

  const percentage = (weight / oneRM) * 100;
  let closestRPE = 1;
  let closestDiff = Math.abs(percentage - (RPE_TABLE[reps]?.[1] || 0));

  for (let rpe = 1; rpe <= 10; rpe++) {
    const tablePercentage = RPE_TABLE[reps]?.[rpe] || 0;
    const diff = Math.abs(percentage - tablePercentage);

    if (diff < closestDiff) {
      closestDiff = diff;
      closestRPE = rpe;
    }
  }

  return closestRPE;
}

export function getRPEDescription(rpe: number): string {
  const descriptions: Record<number, string> = {
    1: 'Very light',
    2: 'Light',
    3: 'Moderate',
    4: 'Moderate',
    5: 'Medium',
    6: 'Medium-Hard',
    7: 'Hard',
    8: 'Very Hard',
    9: 'Maximum Effort',
    10: 'Absolute Maximum',
  };

  return descriptions[Math.round(rpe)] || 'Unknown';
}

export function calculateVolume(weight: number, reps: number, sets: number): number {
  return weight * reps * sets;
}

export function calculateRelativeIntensity(weight: number, oneRM: number): number {
  return (weight / oneRM) * 100;
}
