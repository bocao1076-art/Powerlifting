import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
  Modal,
  FlatList,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { v4 as uuidv4 } from 'uuid';
import { AppData, WorkoutSet, Workout, Exercise } from '../types';
import { addWorkout } from '../utils/storage';
import { calculateRPE } from '../utils/rpeCalculator';
import { colors, spacing, typography, borderRadius } from '../theme/colors';

interface NewWorkoutScreenProps {
  appData: AppData | null;
  onDataChange: () => void;
}

const NewWorkoutScreen: React.FC<NewWorkoutScreenProps> = ({ appData, onDataChange }) => {
  const [sets, setSets] = useState<WorkoutSet[]>([]);
  const [workoutNotes, setWorkoutNotes] = useState('');
  const [selectedBlock, setSelectedBlock] = useState<string>('');
  const [showExerciseModal, setShowExerciseModal] = useState(false);
  const [currentSet, setCurrentSet] = useState<Partial<WorkoutSet>>({
    weight: 0,
    reps: 0,
    sets: 3,
    rpe: 0,
    tags: [],
    notes: '',
  });

  const handleAddSet = () => {
    if (!currentSet.exerciseId || !currentSet.weight || !currentSet.reps || !currentSet.sets) {
      Alert.alert('Erro', 'Preencha todos os campos obrigatórios');
      return;
    }

    const exercise = appData?.exercises.find(e => e.id === currentSet.exerciseId);
    if (!exercise) return;

    // Calculate RPE if 1RM is available
    const oneRM = appData?.oneRMs
      .filter(r => r.exerciseId === currentSet.exerciseId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];

    const rpe = oneRM ? calculateRPE(currentSet.weight!, currentSet.reps!, oneRM.weight) : 0;

    const newSet: WorkoutSet = {
      id: uuidv4(),
      exerciseId: currentSet.exerciseId,
      exerciseName: exercise.name,
      weight: currentSet.weight,
      reps: currentSet.reps,
      sets: currentSet.sets,
      rpe: currentSet.rpe || rpe,
      tags: currentSet.tags || [],
      notes: currentSet.notes || '',
    };

    setSets([...sets, newSet]);
    setCurrentSet({
      weight: 0,
      reps: 0,
      sets: 3,
      rpe: 0,
      tags: [],
      notes: '',
    });
  };

  const handleSaveWorkout = async () => {
    if (sets.length === 0) {
      Alert.alert('Erro', 'Adicione pelo menos um exercício');
      return;
    }

    const workout: Workout = {
      id: uuidv4(),
      date: new Date().toISOString().split('T')[0],
      blockId: selectedBlock,
      sets,
      notes: workoutNotes,
      createdAt: new Date().toISOString(),
    };

    try {
      await addWorkout(workout);
      Alert.alert('Sucesso', 'Treino registrado com sucesso!');
      setSets([]);
      setWorkoutNotes('');
      setSelectedBlock('');
      onDataChange();
    } catch (error) {
      Alert.alert('Erro', 'Falha ao salvar treino');
    }
  };

  const handleRemoveSet = (index: number) => {
    setSets(sets.filter((_, i) => i !== index));
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>📝 Novo Treino</Text>
          <Text style={styles.headerSubtitle}>Registre seus exercícios</Text>
        </View>

        {/* Block Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Bloco de Treino</Text>
          <TouchableOpacity style={styles.selectButton}>
            <Text style={styles.selectButtonText}>
              {selectedBlock ? appData?.blocks.find(b => b.id === selectedBlock)?.name : 'Selecione um bloco'}
            </Text>
            <Ionicons name="chevron-down" size={20} color={colors.primary} />
          </TouchableOpacity>
        </View>

        {/* Exercise Input */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Adicionar Exercício</Text>
          
          <TouchableOpacity
            style={styles.exerciseButton}
            onPress={() => setShowExerciseModal(true)}
          >
            <Ionicons name="add-circle" size={24} color={colors.primary} />
            <Text style={styles.exerciseButtonText}>
              {currentSet.exerciseId
                ? appData?.exercises.find(e => e.id === currentSet.exerciseId)?.name
                : 'Selecione um exercício'}
            </Text>
          </TouchableOpacity>

          {/* Input Fields */}
          <View style={styles.inputRow}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Carga (kg)</Text>
              <TextInput
                style={styles.input}
                placeholder="0"
                placeholderTextColor={colors.textMuted}
                keyboardType="decimal-pad"
                value={currentSet.weight?.toString()}
                onChangeText={(text) =>
                  setCurrentSet({ ...currentSet, weight: parseFloat(text) || 0 })
                }
              />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Reps</Text>
              <TextInput
                style={styles.input}
                placeholder="0"
                placeholderTextColor={colors.textMuted}
                keyboardType="number-pad"
                value={currentSet.reps?.toString()}
                onChangeText={(text) =>
                  setCurrentSet({ ...currentSet, reps: parseInt(text) || 0 })
                }
              />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Séries</Text>
              <TextInput
                style={styles.input}
                placeholder="3"
                placeholderTextColor={colors.textMuted}
                keyboardType="number-pad"
                value={currentSet.sets?.toString()}
                onChangeText={(text) =>
                  setCurrentSet({ ...currentSet, sets: parseInt(text) || 3 })
                }
              />
            </View>
          </View>

          <TouchableOpacity style={styles.addButton} onPress={handleAddSet}>
            <Ionicons name="add" size={24} color={colors.background} />
            <Text style={styles.addButtonText}>Adicionar Série</Text>
          </TouchableOpacity>
        </View>

        {/* Sets List */}
        {sets.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>Séries Adicionadas ({sets.length})</Text>
            {sets.map((set, index) => (
              <View key={index} style={styles.setItem}>
                <View style={styles.setInfo}>
                  <Text style={styles.setExercise}>{set.exerciseName}</Text>
                  <Text style={styles.setDetails}>
                    {set.weight}kg × {set.reps} reps × {set.sets} séries • RPE {set.rpe}
                  </Text>
                </View>
                <TouchableOpacity onPress={() => handleRemoveSet(index)}>
                  <Ionicons name="trash" size={20} color={colors.error} />
                </TouchableOpacity>
              </View>
            ))}
          </View>
        )}

        {/* Workout Notes */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Notas do Treino</Text>
          <TextInput
            style={[styles.input, styles.notesInput]}
            placeholder="Adicione notas sobre seu treino..."
            placeholderTextColor={colors.textMuted}
            multiline
            numberOfLines={4}
            value={workoutNotes}
            onChangeText={setWorkoutNotes}
          />
        </View>

        {/* Save Button */}
        <TouchableOpacity
          style={[styles.saveButton, sets.length === 0 && styles.saveButtonDisabled]}
          onPress={handleSaveWorkout}
          disabled={sets.length === 0}
        >
          <Ionicons name="checkmark-circle" size={24} color={colors.background} />
          <Text style={styles.saveButtonText}>Salvar Treino</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Exercise Modal */}
      <Modal
        visible={showExerciseModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowExerciseModal(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Selecione um Exercício</Text>
              <TouchableOpacity onPress={() => setShowExerciseModal(false)}>
                <Ionicons name="close" size={24} color={colors.text} />
              </TouchableOpacity>
            </View>
            <FlatList
              data={appData?.exercises || []}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.exerciseOption}
                  onPress={() => {
                    setCurrentSet({ ...currentSet, exerciseId: item.id });
                    setShowExerciseModal(false);
                  }}
                >
                  <Text style={styles.exerciseOptionText}>{item.name}</Text>
                  <Text style={styles.exerciseCategory}>{item.category}</Text>
                </TouchableOpacity>
              )}
            />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.lg,
  },
  header: {
    marginBottom: spacing.xl,
  },
  headerTitle: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  headerSubtitle: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
  },
  section: {
    marginBottom: spacing.xl,
  },
  sectionLabel: {
    fontSize: typography.fontSize.sm,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: spacing.md,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  selectButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  selectButtonText: {
    color: colors.text,
    fontSize: typography.fontSize.base,
    flex: 1,
  },
  exerciseButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    gap: spacing.md,
  },
  exerciseButtonText: {
    color: colors.text,
    fontSize: typography.fontSize.base,
    flex: 1,
  },
  inputRow: {
    flexDirection: 'row',
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  inputGroup: {
    flex: 1,
  },
  inputLabel: {
    fontSize: typography.fontSize.xs,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
    fontWeight: '600',
  },
  input: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    color: colors.text,
    fontSize: typography.fontSize.base,
    borderWidth: 1,
    borderColor: colors.border,
  },
  notesInput: {
    height: 100,
    textAlignVertical: 'top',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.md,
    gap: spacing.md,
  },
  addButtonText: {
    color: colors.background,
    fontSize: typography.fontSize.base,
    fontWeight: '600',
  },
  setItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
  },
  setInfo: {
    flex: 1,
  },
  setExercise: {
    color: colors.text,
    fontWeight: '600',
    fontSize: typography.fontSize.base,
    marginBottom: spacing.sm,
  },
  setDetails: {
    color: colors.textSecondary,
    fontSize: typography.fontSize.sm,
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.success,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.lg,
    gap: spacing.md,
    marginBottom: spacing.xl,
  },
  saveButtonDisabled: {
    backgroundColor: colors.textMuted,
    opacity: 0.5,
  },
  saveButtonText: {
    color: colors.background,
    fontSize: typography.fontSize.base,
    fontWeight: '600',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: borderRadius.xl,
    borderTopRightRadius: borderRadius.xl,
    maxHeight: '80%',
    paddingTop: spacing.lg,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700',
    color: colors.text,
  },
  exerciseOption: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  exerciseOptionText: {
    color: colors.text,
    fontSize: typography.fontSize.base,
    fontWeight: '500',
    marginBottom: spacing.sm,
  },
  exerciseCategory: {
    color: colors.textSecondary,
    fontSize: typography.fontSize.xs,
  },
});

export default NewWorkoutScreen;
