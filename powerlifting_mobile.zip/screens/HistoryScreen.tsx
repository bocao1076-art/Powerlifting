import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppData, Workout } from '../types';
import { colors, spacing, typography, borderRadius } from '../theme/colors';
import { exportToCSV, shareCSV } from '../utils/csvManager';

interface HistoryScreenProps {
  appData: AppData | null;
  onDataChange: () => void;
}

const HistoryScreen: React.FC<HistoryScreenProps> = ({ appData, onDataChange }) => {
  const [sortedWorkouts, setSortedWorkouts] = useState<Workout[]>([]);

  useEffect(() => {
    if (appData) {
      const sorted = [...appData.workouts].sort(
        (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
      );
      setSortedWorkouts(sorted);
    }
  }, [appData]);

  const handleExportCSV = async () => {
    if (!appData) return;
    try {
      const filepath = await exportToCSV(appData);
      await shareCSV(filepath);
    } catch (error) {
      Alert.alert('Erro', 'Falha ao exportar dados');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>📊 Histórico de Treinos</Text>
          <TouchableOpacity style={styles.exportButton} onPress={handleExportCSV}>
            <Ionicons name="download" size={20} color={colors.background} />
            <Text style={styles.exportButtonText}>Exportar CSV</Text>
          </TouchableOpacity>
        </View>

        {/* Workouts List */}
        {sortedWorkouts.length > 0 ? (
          sortedWorkouts.map((workout, index) => (
            <View key={index} style={styles.workoutCard}>
              <View style={styles.workoutHeader}>
                <Text style={styles.workoutDate}>
                  {new Date(workout.date).toLocaleDateString('pt-BR', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </Text>
                <Text style={styles.workoutCount}>{workout.sets.length} exercícios</Text>
              </View>

              {workout.sets.map((set, setIndex) => (
                <View key={setIndex} style={styles.setRow}>
                  <View style={styles.setDetails}>
                    <Text style={styles.exerciseName}>{set.exerciseName}</Text>
                    <Text style={styles.setInfo}>
                      {set.weight}kg × {set.reps} × {set.sets} • RPE {set.rpe}
                    </Text>
                  </View>
                  {set.tags.length > 0 && (
                    <View style={styles.tagsContainer}>
                      {set.tags.map((tag, tagIndex) => (
                        <View key={tagIndex} style={styles.tag}>
                          <Text style={styles.tagText}>{tag}</Text>
                        </View>
                      ))}
                    </View>
                  )}
                </View>
              ))}

              {workout.notes && (
                <View style={styles.notesContainer}>
                  <Text style={styles.notesLabel}>Notas:</Text>
                  <Text style={styles.notesText}>{workout.notes}</Text>
                </View>
              )}
            </View>
          ))
        ) : (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyIcon}>📭</Text>
            <Text style={styles.emptyText}>Nenhum treino registrado ainda</Text>
            <Text style={styles.emptySubtext}>Comece registrando seu primeiro treino!</Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.lg,
  },
  header: {
    marginBottom: spacing.xl,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700',
    color: colors.text,
  },
  exportButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    gap: spacing.sm,
  },
  exportButtonText: {
    color: colors.background,
    fontWeight: '600',
    fontSize: typography.fontSize.sm,
  },
  workoutCard: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.lg,
    borderLeftWidth: 4,
    borderLeftColor: colors.primary,
  },
  workoutHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  workoutDate: {
    fontSize: typography.fontSize.base,
    fontWeight: '600',
    color: colors.text,
    textTransform: 'capitalize',
  },
  workoutCount: {
    fontSize: typography.fontSize.sm,
    color: colors.primary,
    fontWeight: '600',
  },
  setRow: {
    marginBottom: spacing.md,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  setDetails: {
    marginBottom: spacing.sm,
  },
  exerciseName: {
    fontSize: typography.fontSize.base,
    fontWeight: '600',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  setInfo: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  tag: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.sm,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
  },
  tagText: {
    color: colors.background,
    fontSize: typography.fontSize.xs,
    fontWeight: '600',
  },
  notesContainer: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginTop: spacing.md,
  },
  notesLabel: {
    fontSize: typography.fontSize.sm,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  notesText: {
    fontSize: typography.fontSize.sm,
    color: colors.text,
    lineHeight: 20,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing['3xl'],
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: spacing.lg,
  },
  emptyText: {
    fontSize: typography.fontSize.lg,
    fontWeight: '600',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  emptySubtext: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
  },
});

export default HistoryScreen;
