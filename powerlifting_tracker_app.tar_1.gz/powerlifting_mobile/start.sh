#!/bin/bash

# Powerlifting Tracker Pro - Start Script
# Este script instala dependências e inicia o app

echo "🏋️ Powerlifting Tracker Pro - Dark Zone Edition"
echo "================================================"
echo ""

# Verificar se Node.js está instalado
if ! command -v node &> /dev/null; then
    echo "❌ Node.js não está instalado!"
    echo "Baixe em: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js encontrado: $(node --version)"
echo ""

# Ir para o diretório do projeto
cd "$(dirname "$0")"

# Instalar Expo CLI globalmente se não estiver instalado
if ! command -v expo &> /dev/null; then
    echo "📦 Instalando Expo CLI..."
    npm install -g expo-cli
    echo "✅ Expo CLI instalado!"
    echo ""
fi

# Instalar dependências do projeto
if [ ! -d "node_modules" ]; then
    echo "📦 Instalando dependências do projeto..."
    npm install
    echo "✅ Dependências instaladas!"
    echo ""
fi

# Iniciar o app
echo "🚀 Iniciando Powerlifting Tracker Pro..."
echo ""
echo "📱 Instruções:"
echo "1. Instale 'Expo Go' no seu celular (Google Play ou App Store)"
echo "2. Abra o Expo Go"
echo "3. Escaneie o QR code que aparecerá abaixo"
echo "4. Pronto! Seu app está rodando!"
echo ""
echo "================================================"
echo ""

expo start
