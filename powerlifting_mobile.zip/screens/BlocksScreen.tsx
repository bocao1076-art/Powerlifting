import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { v4 as uuidv4 } from 'uuid';
import { AppData, TrainingBlock, TrainingDay } from '../types';
import { addTrainingBlock } from '../utils/storage';
import { colors, spacing, typography, borderRadius } from '../theme/colors';

interface BlocksScreenProps {
  appData: AppData | null;
  onDataChange: () => void;
}

const BlocksScreen: React.FC<BlocksScreenProps> = ({ appData, onDataChange }) => {
  const [showNewBlockModal, setShowNewBlockModal] = useState(false);
  const [blockName, setBlockName] = useState('');
  const [blockType, setBlockType] = useState<'accumulation' | 'intensification' | 'realization' | 'deload'>('accumulation');
  const [weekNumber, setWeekNumber] = useState('1');

  const blockTypeLabels = {
    accumulation: 'Acumulação (Volume)',
    intensification: 'Intensificação (Força)',
    realization: 'Realização (Pico)',
    deload: 'Deload (Recuperação)',
  };

  const handleCreateBlock = async () => {
    if (!blockName.trim()) {
      Alert.alert('Erro', 'Digite um nome para o bloco');
      return;
    }

    const newBlock: TrainingBlock = {
      id: uuidv4(),
      name: blockName,
      startDate: new Date().toISOString().split('T')[0],
      endDate: undefined,
      weekNumber: parseInt(weekNumber) || 1,
      blockType,
      days: [],
    };

    try {
      await addTrainingBlock(newBlock);
      Alert.alert('Sucesso', 'Bloco criado com sucesso!');
      setBlockName('');
      setWeekNumber('1');
      setBlockType('accumulation');
      setShowNewBlockModal(false);
      onDataChange();
    } catch (error) {
      Alert.alert('Erro', 'Falha ao criar bloco');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>📅 Blocos de Treino</Text>
          <TouchableOpacity
            style={styles.newBlockButton}
            onPress={() => setShowNewBlockModal(true)}
          >
            <Ionicons name="add-circle" size={24} color={colors.background} />
            <Text style={styles.newBlockButtonText}>Novo Bloco</Text>
          </TouchableOpacity>
        </View>

        {/* Blocks List */}
        {appData && appData.blocks.length > 0 ? (
          appData.blocks.map((block, index) => (
            <View key={index} style={styles.blockCard}>
              <View style={styles.blockHeader}>
                <View style={styles.blockTitleContainer}>
                  <Text style={styles.blockName}>{block.name}</Text>
                  <Text style={styles.blockWeek}>Semana {block.weekNumber}</Text>
                </View>
                <View style={[styles.blockTypeBadge, { backgroundColor: getBlockTypeColor(block.blockType) }]}>
                  <Text style={styles.blockTypeText}>
                    {blockTypeLabels[block.blockType].split(' ')[0]}
                  </Text>
                </View>
              </View>

              <View style={styles.blockInfo}>
                <View style={styles.infoItem}>
                  <Ionicons name="calendar" size={16} color={colors.primary} />
                  <Text style={styles.infoText}>
                    Início: {new Date(block.startDate).toLocaleDateString('pt-BR')}
                  </Text>
                </View>
                {block.endDate && (
                  <View style={styles.infoItem}>
                    <Ionicons name="calendar" size={16} color={colors.primary} />
                    <Text style={styles.infoText}>
                      Fim: {new Date(block.endDate).toLocaleDateString('pt-BR')}
                    </Text>
                  </View>
                )}
              </View>

              <View style={styles.blockDescription}>
                <Text style={styles.descriptionText}>
                  {blockTypeLabels[block.blockType]}
                </Text>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyIcon}>📭</Text>
            <Text style={styles.emptyText}>Nenhum bloco criado ainda</Text>
            <Text style={styles.emptySubtext}>Crie seu primeiro bloco de treino!</Text>
          </View>
        )}

        {/* Info Card */}
        <View style={styles.infoCard}>
          <Text style={styles.infoCardTitle}>💡 Dica: Estrutura de Blocos</Text>
          <Text style={styles.infoCardText}>
            • Acumulação: 3-4 semanas de volume alto{'\n'}
            • Intensificação: 2-3 semanas de força{'\n'}
            • Realização: 1-2 semanas de pico{'\n'}
            • Deload: 1 semana de recuperação
          </Text>
        </View>
      </ScrollView>

      {/* New Block Modal */}
      <Modal
        visible={showNewBlockModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowNewBlockModal(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Novo Bloco de Treino</Text>
              <TouchableOpacity onPress={() => setShowNewBlockModal(false)}>
                <Ionicons name="close" size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            <View style={styles.modalBody}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Nome do Bloco</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Ex: Bloco 1 - Acumulação"
                  placeholderTextColor={colors.textMuted}
                  value={blockName}
                  onChangeText={setBlockName}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Tipo de Bloco</Text>
                {Object.entries(blockTypeLabels).map(([key, label]) => (
                  <TouchableOpacity
                    key={key}
                    style={[
                      styles.typeOption,
                      blockType === key && styles.typeOptionSelected,
                    ]}
                    onPress={() => setBlockType(key as any)}
                  >
                    <View
                      style={[
                        styles.typeOptionCheckbox,
                        blockType === key && styles.typeOptionCheckboxSelected,
                      ]}
                    >
                      {blockType === key && (
                        <Ionicons name="checkmark" size={16} color={colors.background} />
                      )}
                    </View>
                    <Text style={styles.typeOptionText}>{label}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Número da Semana</Text>
                <TextInput
                  style={styles.input}
                  placeholder="1"
                  placeholderTextColor={colors.textMuted}
                  keyboardType="number-pad"
                  value={weekNumber}
                  onChangeText={setWeekNumber}
                />
              </View>

              <TouchableOpacity style={styles.createButton} onPress={handleCreateBlock}>
                <Ionicons name="checkmark-circle" size={24} color={colors.background} />
                <Text style={styles.createButtonText}>Criar Bloco</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const getBlockTypeColor = (type: string): string => {
  switch (type) {
    case 'accumulation':
      return '#3B82F6'; // Blue
    case 'intensification':
      return '#F59E0B'; // Amber
    case 'realization':
      return '#EF4444'; // Red
    case 'deload':
      return '#10B981'; // Green
    default:
      return colors.primary;
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.lg,
  },
  header: {
    marginBottom: spacing.xl,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700',
    color: colors.text,
  },
  newBlockButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    gap: spacing.sm,
  },
  newBlockButtonText: {
    color: colors.background,
    fontWeight: '600',
    fontSize: typography.fontSize.sm,
  },
  blockCard: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.lg,
    borderLeftWidth: 4,
    borderLeftColor: colors.primary,
  },
  blockHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.md,
  },
  blockTitleContainer: {
    flex: 1,
  },
  blockName: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  blockWeek: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
  },
  blockTypeBadge: {
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  blockTypeText: {
    color: colors.background,
    fontWeight: '600',
    fontSize: typography.fontSize.xs,
  },
  blockInfo: {
    marginBottom: spacing.md,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginBottom: spacing.sm,
  },
  infoText: {
    color: colors.textSecondary,
    fontSize: typography.fontSize.sm,
  },
  blockDescription: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    padding: spacing.md,
  },
  descriptionText: {
    color: colors.text,
    fontSize: typography.fontSize.sm,
    fontWeight: '500',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing['3xl'],
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: spacing.lg,
  },
  emptyText: {
    fontSize: typography.fontSize.lg,
    fontWeight: '600',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  emptySubtext: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
  },
  infoCard: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.xl,
  },
  infoCardTitle: {
    fontSize: typography.fontSize.base,
    fontWeight: '700',
    color: colors.background,
    marginBottom: spacing.md,
  },
  infoCardText: {
    fontSize: typography.fontSize.sm,
    color: colors.background,
    lineHeight: 22,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: borderRadius.xl,
    borderTopRightRadius: borderRadius.xl,
    paddingTop: spacing.lg,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700',
    color: colors.text,
  },
  modalBody: {
    padding: spacing.lg,
  },
  inputGroup: {
    marginBottom: spacing.lg,
  },
  inputLabel: {
    fontSize: typography.fontSize.sm,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: spacing.md,
  },
  input: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    color: colors.text,
    fontSize: typography.fontSize.base,
    borderWidth: 1,
    borderColor: colors.border,
  },
  typeOption: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  typeOptionSelected: {
    borderColor: colors.primary,
    backgroundColor: colors.primary + '20',
  },
  typeOptionCheckbox: {
    width: 24,
    height: 24,
    borderRadius: borderRadius.sm,
    borderWidth: 2,
    borderColor: colors.border,
    marginRight: spacing.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  typeOptionCheckboxSelected: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  typeOptionText: {
    color: colors.text,
    fontSize: typography.fontSize.base,
    fontWeight: '500',
  },
  createButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.lg,
    gap: spacing.md,
    marginTop: spacing.lg,
  },
  createButtonText: {
    color: colors.background,
    fontSize: typography.fontSize.base,
    fontWeight: '600',
  },
});

export default BlocksScreen;
