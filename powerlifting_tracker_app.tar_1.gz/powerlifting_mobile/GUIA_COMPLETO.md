# 🏋️ Powerlifting Tracker Pro - Guia Completo

## 📱 Seu App está Pronto!

Parabéns! Você tem um **aplicativo mobile profissional** de rastreamento de powerlifting com design dark zone roxo e preto! 🔥

---

## 🚀 Como Usar (3 Passos Simples)

### ✅ Passo 1: Instale o Expo Go no Celular

**Android:**
1. Abra Google Play Store
2. Procure por "Expo Go"
3. Instale (é grátis!)

**iPhone:**
1. Abra App Store
2. Procure por "Expo Go"
3. Instale (é grátis!)

### ✅ Passo 2: Prepare seu Computador

**Windows:**
1. Baixe Node.js em https://nodejs.org/ (versão LTS)
2. Instale normalmente
3. Abra o Prompt de Comando (cmd)

**Mac/Linux:**
1. Instale Node.js via Homebrew: `brew install node`
2. Abra o Terminal

### ✅ Passo 3: Inicie o App

**Windows:**
1. Abra o Prompt de Comando
2. Digite:
```bash
cd /home/ubuntu/powerlifting_mobile
npm install -g expo-cli
npm install
expo start
```

**Mac/Linux:**
1. Abra o Terminal
2. Digite:
```bash
cd /home/ubuntu/powerlifting_mobile
npm install -g expo-cli
npm install
expo start
```

3. Quando aparecer o QR code no terminal:
   - Abra o Expo Go no celular
   - Toque em "Scan QR code"
   - Aponte para o QR code
   - **Pronto!** 🎉

---

## 📖 Como Usar o App

### 🏠 Dashboard (Home)
- **Total SBD**: Seu total atual (Squat + Bench + Deadlift)
- **1RMs**: Seus máximos registrados
- **Últimos Treinos**: Visualize os 5 treinos mais recentes

### ➕ Novo Treino
1. Toque em "Novo Treino"
2. Selecione um bloco (opcional)
3. Escolha um exercício
4. Digite:
   - **Carga (kg)**: Peso usado
   - **Repetições**: Quantas reps fez
   - **Séries**: Quantas séries
5. **RPE é calculado automaticamente!**
6. Toque "Salvar Treino"

**Exemplo:**
- Exercício: Squat
- Carga: 150kg
- Reps: 5
- Séries: 3
- RPE: Calculado automaticamente (8/10)

### 📅 Blocos de Treino
1. Toque em "Blocos"
2. Toque "Novo Bloco"
3. Configure:
   - **Nome**: Ex: "Bloco 1 - Acumulação"
   - **Tipo**: Acumulação, Intensificação, Realização ou Deload
   - **Semana**: Número da semana (1-52)
4. Salve o bloco

### 📊 Análise (NOVO!)
- **Gráficos de Evolução**: Veja seu progresso em Squat, Bench e Deadlift
- **Estatísticas**: Volume total, RPE médio, número de séries
- **Distribuição**: Quantos treinos pesados, moderados e leves
- **Insights**: Exercício mais feito, carga máxima, tendência

### 📋 Histórico
- Visualize **todos os seus treinos**
- Filtre por bloco ou data
- **Exporte em CSV** (compatível com Obsidian!)

### ⚙️ Configurações
- **Registre 1RMs**: Adicione seus máximos (Squat, Bench, Deadlift)
- **Visualize Backups**: Veja arquivos salvos
- **Limpe Dados**: Apague tudo se necessário (cuidado!)

---

## 📊 Cálculo de RPE

O app calcula RPE automaticamente baseado em:
- **Seu 1RM** (máximo registrado)
- **Carga do treino**
- **Repetições**

**Tabela de RPE (Borg 1-10):**
- **1-3**: Muito fácil (aquecimento)
- **4-5**: Fácil (volume)
- **6-7**: Moderado (trabalho)
- **8-9**: Difícil (intenso)
- **10**: Máximo (limite absoluto)

---

## 💾 Exportar para CSV (Obsidian)

1. Toque em "Histórico"
2. Toque em "Exportar CSV"
3. Escolha onde salvar
4. Abra no Obsidian, Excel ou qualquer editor

**Formato CSV:**
```
Date,Block,Exercise,Weight(kg),Reps,Sets,RPE,Tags,Notes
2026-02-02,Bloco1,Squat,150,5,3,8,"pesado,volume","Bom treino"
2026-02-02,Bloco1,Bench Press,100,6,4,7,"volume","Sentindo forte"
```

---

## 🎨 Design Dark Zone

- **Roxo Vibrante**: #8B5CF6 (cores principais)
- **Preto Profundo**: #0F0F1E (fundo)
- **Tipografia**: Letras médias elegantes
- **Vibe**: Quando abre, dá vontade de treinar! 💪

---

## 🔒 Dados e Privacidade

✅ **100% Offline**: Nenhum dado é enviado para servidores
✅ **Armazenamento Local**: Tudo fica no seu celular
✅ **Sincronização Manual**: Via arquivo CSV
✅ **Backup Fácil**: Exporte quando quiser

---

## 🐛 Troubleshooting

### "App não conecta"
- Certifique-se que PC e celular estão na **mesma rede WiFi**
- Reinicie o Expo Go
- Execute `expo start` novamente

### "Dados não salvam"
- Verifique espaço no celular
- Tente limpar cache do Expo Go
- Reinstale o app

### "RPE não calcula"
- Registre um 1RM primeiro em Configurações
- O RPE usa seu 1RM mais recente

### "Gráficos não aparecem"
- Adicione mais treinos (precisa de pelo menos 2)
- Verifique se os treinos têm datas diferentes

### "Erro ao exportar CSV"
- Verifique permissões de armazenamento
- Tente novamente em um momento diferente

---

## 📦 Compilar para APK Final

Depois de testar bastante, você pode compilar para um **APK permanente**:

### Opção 1: EAS Build (Recomendado)
```bash
# 1. Crie conta em https://expo.dev (gratuita)
# 2. Faça login
eas login

# 3. Configure
eas build:configure

# 4. Compile
eas build --platform android
```

### Opção 2: Compilação Local
```bash
# Requer Android Studio instalado
cd /home/ubuntu/powerlifting_mobile
npx expo prebuild --clean
cd android
./gradlew assembleRelease
```

---

## 🎯 Dicas Profissionais

### 1. Organize seus Blocos
- **Bloco 1**: Acumulação (volume alto, RPE 6-7)
- **Bloco 2**: Intensificação (volume médio, RPE 7-8)
- **Bloco 3**: Realização (volume baixo, RPE 8-9)
- **Bloco 4**: Deload (volume baixo, RPE 4-5)

### 2. Use Tags
- "pesado" - Treino intenso
- "leve" - Treino de recuperação
- "volume" - Foco em volume
- "intensidade" - Foco em força

### 3. Registre Notas
- "Bom treino" - Dia positivo
- "Cansado" - Dia ruim
- "PR novo!" - Novo recorde pessoal

### 4. Sincronize entre Celulares
- Exporte CSV do celular 1
- Envie via email/WhatsApp
- Importe no celular 2

---

## 📞 Suporte

Se tiver dúvidas:
1. Verifique se Expo Go está atualizado
2. Tente limpar cache: `expo start --clear`
3. Reinstale dependências: `rm -rf node_modules && npm install`

---

## 🎉 Você Está Pronto!

Seu **Powerlifting Tracker Pro** está completo e pronto para revolucionar seu treino!

### Próximos Passos:
1. ✅ Instale Expo Go no celular
2. ✅ Execute `expo start` no PC
3. ✅ Escaneie o QR code
4. ✅ Registre seu primeiro treino!
5. ✅ Acompanhe sua evolução com gráficos
6. ✅ Exporte em CSV para análise

---

## 💪 Boa Sorte nos Treinos!

**Powerlifting Tracker Pro - Dark Zone Edition**

*Seu companheiro perfeito para dominar o powerlifting!* 🔥

---

**Versão**: 1.0.0  
**Data**: Fevereiro 2026  
**Design**: Dark Zone Roxo + Preto  
**Funcionalidades**: 10 completas + gráficos de evolução
